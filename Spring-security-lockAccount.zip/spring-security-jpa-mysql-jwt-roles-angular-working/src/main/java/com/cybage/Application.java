package com.cybage;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.cybage.security.MyUserDetailsService;
import com.cybage.security.SwaggerConfiguration;
import com.cybage.security.User;
import com.cybage.security.UserRepository;

@SpringBootApplication
@EnableAsync
@Import(SwaggerConfiguration.class)
public class Application implements CommandLineRunner{

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
    
    @Autowired
    UserRepository ur;
    
    @Override
    public void run(String... args) throws Exception {
    	
    	User user = new User(1, "user", new BCryptPasswordEncoder().encode("user"), true, 12345, 68, null);
    	List<String> roles = new ArrayList<String>();
    	roles.add("USER");
    	user.setRoles(roles);
        ur.save(user);
//    	//add two users in the beginning
//    	User user  = new User(1, "user", new BCryptPasswordEncoder().encode("user"), true, 1234, 35, null);
//    	List<String> roles = new ArrayList<String>();
//    	roles.add("USER");
//    	user.setRoles(roles);
//        ur.save(user);
        
    	user  = new User(2, "admin", new BCryptPasswordEncoder().encode("admin"),true, 1235, 36, null);
    	roles = new ArrayList<String>();
    	roles.add("ADMIN");
    	user.setRoles(roles);
        ur.save(user);
        
        
        user  = new User(3, "dm", new BCryptPasswordEncoder().encode("dm"),true, 1235, 36, null);
    	roles = new ArrayList<String>();
    	roles.add("ADMIN");
    	user.setRoles(roles);
        ur.save(user);
    }
}
