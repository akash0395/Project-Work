import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent-child2',
  templateUrl: './parent-child2.component.html',
  styleUrls: ['./parent-child2.component.css']
})
export class ParentChild2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
