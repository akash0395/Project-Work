import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-parent',
  template: `
  <h3>You selected department with id = </h3>
  <p>
    <button (click)="showOverview()">Overview</button>
    <button (click)="showContact()">Contact</button>
  </p>
  
  <router-outlet></router-outlet>
  <p>
    <button >Previous</button>
    <button >Next</button>
  </p>
  
`,
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  constructor(private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
  }
  showOverview(){
    this.router.navigate(['overview'], { relativeTo: this.route });
  }
  showContact(){
    this.router.navigate(['contact'], { relativeTo: this.route });
  }

}
