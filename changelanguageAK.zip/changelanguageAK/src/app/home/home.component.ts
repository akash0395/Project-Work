import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { LangService } from '../lang.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  //activeclass:string=''
  browserlang:string

  selectedlang1
  constructor(public translate:TranslateService, private _lang:LangService,private router:Router){

    this._lang.selectedlang.subscribe(res=>{
      console.log("res = "+res)
      this.selectedlang1=res
    })


    translate.addLangs(['de','en'])
    translate.setDefaultLang('en')
    // translate.use('en')
    // this.browserlang=translate.getDefaultLang()
    // this.languagechanged()
    // this._lang.selectedlang.next(this.browserlang)
    // console.log("service "+this._lang.selectedlang.value)
  }

  languagechanged(){
    console.log("inside lang changed")
    this.translate.use(this.browserlang.match(/de|en/) ? this.browserlang:'') 
  }
//https://www.youtube.com/watch?v=e2bpbo_B32s
  




  ngOnInit(): void {
  }


  changelang(lang){
    console.log("inside change lang :"+lang)
    // this.activeclass=lang
    this.translate.use(lang);

    //this._lang.selectedlang.next(lang)
    //console.log("xhange lang methid "+this._lang.selectedlang)
  }
}
