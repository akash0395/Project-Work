import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ParentChild1Component } from './parent-child1/parent-child1.component';
import { ParentChild2Component } from './parent-child2/parent-child2.component';
import { ParentComponent } from './parent/parent.component';


const routes: Routes = [
  {path:'',component:ParentComponent},
  { path: 'home', component: HomeComponent},

  {path:'parent',component:ParentComponent,
  children: [
    { path: 'overview', component: ParentChild1Component},
    { path: 'contact', component: ParentChild2Component},

  ]
},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponent=[
                                ParentComponent,
                                ParentChild1Component,
                                ParentChild2Component
                                ]