import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LangService } from './lang.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'demo';
  theme:string=localStorage.getItem('theme')

  activeclass:string=''
  browserlang:string

  selectedlang1
  constructor(public translate:TranslateService, private _lang:LangService){

    this._lang.selectedlang.subscribe(res=>{
      console.log("res = "+res)
      this.selectedlang1=res
    })


    translate.addLangs(['de','en'])
    translate.setDefaultLang('en')
    translate.use('en')
    this.browserlang=translate.getDefaultLang()
    this.languagechanged()
    this._lang.selectedlang.next(this.browserlang)
    console.log("service "+this._lang.selectedlang)
  }

  languagechanged(){
    this.translate.use(this.browserlang.match(/de|en/) ? this.browserlang:'de') 
  }
//https://www.youtube.com/watch?v=e2bpbo_B32s
  




  ngOnInit(): void {
  }

  setTheme(theme){

    localStorage.setItem('theme',theme )
    this.theme=localStorage.getItem('theme')

  }


  changelang(lang){
    console.log(lang)
    // this.activeclass=lang
    this._lang.selectedlang.next(lang)
    console.log(this._lang.selectedlang)
  }
}
