import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent-child1',
  templateUrl: './parent-child1.component.html',
  styleUrls: ['./parent-child1.component.css']
})
export class ParentChild1Component implements OnInit {
  theme:string=localStorage.getItem('theme')

  constructor() { }

  ngOnInit(): void {
    console.log(this.theme)
  }

}
