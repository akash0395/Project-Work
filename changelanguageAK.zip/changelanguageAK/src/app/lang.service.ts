import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LangService {

  constructor() { }
  selectedlang=new BehaviorSubject('de')
 
}
